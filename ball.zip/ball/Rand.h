#pragma once

class Rand {
public:
  static double range(double a = 0, double b = 1);
};
