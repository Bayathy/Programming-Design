USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
bayathy     6358  3.8  1.0 1457372 81404 pts/0   Sl+  18:48   0:03 ./main

USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
bayathy     7373  7.0  1.1 1457616 82928 pts/0   Sl+  18:55   0:01 ./main

USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
bayathy     7503  160  1.5 1487868 114496 pts/0  Rl+  18:56   0:16 ./main

USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
bayathy     9556  5.5  1.0 1457392 81808 pts/0   Sl+  19:28   0:00 ./main

USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
bayathy     9706  6.8  1.0 1457428 81276 pts/0   Sl+  19:29   0:00 ./main

USER         PID %CPU %MEM    VSZ   RSS TTY      STAT START   TIME COMMAND
bayathy     9866  107  1.1 1460764 86236 pts/0   Rl+  19:34   0:20 ./main